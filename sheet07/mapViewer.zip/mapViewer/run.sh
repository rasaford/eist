#!/bin/bash
echo "Running .jar file"

java -jar ./out/artifacts/mapViewer_jar/mapViewer.jar
